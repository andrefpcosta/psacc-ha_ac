## What's Changed
- Added C4 Grand Picasso Diesel carmodel by @matty87a in Added C4 Grand Picasso Diesel carmodel #290
- Adding Citroen C3 Model 2021 by @Zwordi in Adding Citroen C3 Model 2021 #334
- v3 by @flobz in v3 #337
- Add restart policy to docker-compose by @Apollon77 in Add restart policy to docker-compose #344
- Update car_models.yml by @BenAChilds in Update car_models.yml #338
- Automatically postpone scheduled charge time when percentage threshold is set (closes Feature Request: Automatically postpone scheduled charge time when percentage threshold is set #339) by @cbruegg in Automatically postpone scheduled charge time when percentage threshold is set (closes #339) #349
- Add C3 Aircross model by @acesyde in Add C3 Aircross model #355
- Removed redudant [SE] block by @vinnie1234 in Removed redudant [SE] block #353
- New Contributors

## New Contributors
- @matty87a made their first contribution in Added C4 Grand Picasso Diesel carmodel #290
- @Zwordi made their first contribution in Adding Citroen C3 Model 2021 #334
- @Apollon77 made their first contribution in Add restart policy to docker-compose #344
- @BenAChilds made their first contribution in Update car_models.yml #338
- @cbruegg made their first contribution in Automatically postpone scheduled charge time when percentage threshold is set (closes #339) #349
- @acesyde made their first contribution in Add C3 Aircross model #355
- @vinnie1234 made their first contribution in Removed redudant [SE] block #353

Full Changelog: [v2.6.0...v3.0.3](https://github.com/flobz/psa_car_controller/compare/v2.6.0...v3.0.3)
